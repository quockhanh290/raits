# RAITS Phase 1 - Step 1.4: Data Quality Validation

## 📦 Overview

**Comprehensive data quality validation system** to ensure clean, reliable data before backtesting. This step is **critical** for avoiding:
- ✅ Survivorship bias (testing only on "winners")
- ✅ Lookahead bias (future data in past)
- ✅ Bad data (missing bars, price errors, volume issues)
- ✅ Corporate action errors (bad split adjustments)

**Why this matters:** Bad data = Bad backtest results = False confidence = Real money losses

---

## 🎯 What's Included

### Core Module

**raits_data_validator.py** (~600 lines) - Comprehensive validation engine

**Features:**
- Survivorship bias detection
- Missing data & gap analysis
- Corporate actions validation (splits/dividends)
- Price anomaly detection
- Volume issue checking
- OHLC consistency verification
- Quality scoring (0-100)

### Usage Examples

**example_data_validation.py** (~450 lines) - 7 working examples

**Demonstrates:**
1. Basic validation
2. Custom thresholds
3. Selective checks
4. Universe validation
5. Corporate actions
6. Survivorship bias
7. Pass/fail decisions

---

## 🚀 Quick Start

### 1. Copy Files

```bash
# Navigate to your RAITS project
cd ~/projects/RAITS

# Copy validation files
cp raits_data_validator.py raits/data/
cp example_data_validation.py .
```

### 2. Run Examples

```bash
# Activate venv
source venv/bin/activate

# Run validation examples
python example_data_validation.py
```

**Expected output:**
```
======================================================================
                   RAITS DATA QUALITY VALIDATION
======================================================================

============================================================
EXAMPLE 1: Basic Data Quality Check
============================================================

Fetching AAPL data...
⚠️  API key not configured, using mock data for AAPL
Running validation...

Data Quality Report: AAPL
Status: ✓ PASS (Score: 95.0/100)
Period: 2024-XX-XX to 2025-XX-XX
Bars: 252/252 (0.0% missing)

Corporate Actions:
  - Splits: 0
  - Dividends: 0
...
```

### 3. Basic Usage

```python
from raits.data.raits_data_pipeline import DataPipeline
from raits.data.raits_data_validator import validate_data

# Fetch data
pipeline = DataPipeline(api_key=None)
data = pipeline.get_daily_data("AAPL", start_date, end_date)

# Validate
report = validate_data(data)

# Check results
if report.passed:
    print(f"✓ Data quality: PASS ({report.quality_score}/100)")
else:
    print(f"✗ Data quality: FAIL")
    for issue in report.get_critical_issues():
        print(f"  - {issue}")
```

---

## 🔍 What Gets Validated

### 1. Missing Data & Gaps

**Checks:**
- Expected vs actual trading days
- Missing bar percentage
- Multi-day gaps (3+ consecutive days)

**Thresholds:**
- Default: 5% missing data allowed
- Configurable per use case

**Example:**
```python
validator = DataQualityValidator(max_missing_pct=3.0)  # Stricter
report = validator.validate(data)

print(f"Missing: {report.missing_percentage:.1f}%")
print(f"Gaps: {len(report.gap_dates)}")
```

### 2. Survivorship Bias

**What it is:**
Testing only on stocks that are currently trading (survivors) while excluding delisted/bankrupt companies. This creates unrealistically good results.

**Checks:**
- Is stock currently active?
- Was it delisted during test period?
- Do we have data through delisting?

**Critical for:**
- Realistic backtest results
- Avoiding overfitting to "winners"
- Understanding true risk

**Example:**
```python
report = validate_data(data)

print(f"Active: {report.is_currently_active}")
print(f"Delisted: {report.delisted_date}")
print(f"Bias risk: {report.has_survivorship_bias_risk}")
```

### 3. Corporate Actions

**Validates:**
- Stock splits (2-for-1, 3-for-1, etc.)
- Dividends
- Proper price adjustments

**Why it matters:**
- Unadjusted data shows false price drops
- Incorrect adjustments give wrong signals

**Example:**
```python
report = validate_data(data)

print(f"Splits: {len(report.splits)}")
print(f"Dividends: {len(report.dividends)}")

# Check if properly adjusted
for split in report.splits:
    print(f"  {split.ex_date}: {split.split_ratio}-for-1")
```

### 4. Price Anomalies

**Detects:**
- Extreme moves (>20% single day)
- Price spikes (>3 std devs)
- Negative/zero prices
- Flat prices (high = low)

**Configurable:**
```python
validator = DataQualityValidator(
    extreme_move_threshold=0.15,  # 15% instead of 20%
    price_spike_threshold=4.0     # 4 std devs instead of 3
)
```

**Example:**
```python
report = validate_data(data)

for date, pct in report.extreme_moves:
    print(f"  {date}: {pct:+.1f}% move")
```

### 5. Volume Issues

**Checks:**
- Zero volume days (no trading)
- Very low volume (illiquid)
- Volume spikes (unusual activity)

**Why it matters:**
- Zero volume = can't execute trades
- Low volume = high slippage
- Spikes = news events, consider excluding

**Example:**
```python
report = validate_data(data)

print(f"Zero volume: {len(report.zero_volume_days)} days")
print(f"Low volume: {len(report.low_volume_days)} days")
print(f"Spikes: {len(report.volume_spikes)}")
```

### 6. OHLC Consistency

**Validates:**
- High >= Low (always)
- High >= Open and Close
- Low <= Open and Close

**Example violations:**
- High: $100, Low: $105 ❌
- High: $100, Open: $105 ❌

**These are data errors, not market behavior.**

---

## 📊 Quality Scoring

### How Scores Work

**Starting point:** 100 points

**Deductions:**
- Critical issue: -20 points
- Warning: -5 points
- Info: -1 point

**Pass criteria:**
- No critical issues
- Score >= 70
- Missing data <= threshold

### Score Interpretation

| Score | Quality | Action |
|---|---|---|
| 90-100 | Excellent | Use for backtesting |
| 80-89 | Good | Acceptable, monitor |
| 70-79 | Fair | Use with caution |
| 60-69 | Poor | Investigate issues |
| <60 | Very Poor | Do not use |

### Example

```python
report = validate_data(data)

print(f"Score: {report.quality_score}/100")

if report.quality_score >= 90:
    print("✓ Excellent quality")
elif report.quality_score >= 80:
    print("✓ Good quality")
elif report.quality_score >= 70:
    print("⚠️  Fair quality - use caution")
else:
    print("✗ Poor quality - do not use")
```

---

## 🎯 Practical Usage

### Use Case 1: Single Ticker Validation

```python
from raits.data.raits_data_pipeline import quick_daily_data
from raits.data.raits_data_validator import validate_data

# Fetch data
data = quick_daily_data("AAPL", days=252)

# Validate
report = validate_data(data)

# Decision
if report.passed:
    print("✓ Ready for backtesting")
    df = data.to_dataframe()
    # Proceed with strategy
else:
    print("✗ Data quality issues - fix or exclude")
    for issue in report.get_critical_issues():
        print(f"  {issue}")
```

### Use Case 2: Universe Filtering

```python
from raits.data.raits_data_pipeline import quick_universe
from raits.data.raits_data_validator import validate_universe

# Build universe
tickers = ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA", 
           "META", "NVDA", "AMD", "NFLX", "DIS"]
universe = quick_universe(tickers, days=252)

# Validate all
reports = validate_universe(universe)

# Filter by quality
good_tickers = [
    ticker for ticker, report in reports.items()
    if report.passed and report.quality_score >= 85
]

print(f"Acceptable for trading: {good_tickers}")
print(f"Rejected: {len(reports) - len(good_tickers)} tickers")

# Use only good quality data
filtered_universe = {
    ticker: universe[ticker]
    for ticker in good_tickers
}
```

### Use Case 3: Custom Validation Rules

```python
from raits.data.raits_data_validator import DataQualityValidator

# Create validator with strict rules for high-frequency strategy
validator = DataQualityValidator(
    max_missing_pct=1.0,          # Only 1% missing allowed
    extreme_move_threshold=0.10,   # Flag >10% moves
    min_volume_threshold=1000000,  # Require 1M+ volume
    zero_volume_critical=True      # Zero volume = fail
)

# Validate
report = validator.validate(data)

# Only use if passes strict criteria
if report.passed and report.quality_score >= 95:
    print("✓ Meets strict HFT criteria")
else:
    print("✗ Does not meet requirements")
```

### Use Case 4: Pre-WFO Validation

```python
# Before Walk-Forward Optimization, validate ALL data
from raits.data.raits_data_pipeline import DataPipeline
from raits.data.raits_data_validator import validate_universe

pipeline = DataPipeline(api_key=POLYGON_API_KEY)  # Real data now

# Build full universe for WFO
universe_tickers = load_universe_list()  # Your 50-100 tickers
universe = pipeline.build_universe(
    tickers=universe_tickers,
    start_date=datetime(2020, 1, 1),
    end_date=datetime(2024, 12, 31)
)

# Validate everything
print("Validating full universe before WFO...")
reports = validate_universe(universe, show_progress=True)

# Generate quality report
passed = sum(1 for r in reports.values() if r.passed)
print(f"\nQuality Summary:")
print(f"  Total tickers: {len(reports)}")
print(f"  Passed: {passed}")
print(f"  Failed: {len(reports) - passed}")

# Identify tickers to exclude
excluded = [
    ticker for ticker, report in reports.items()
    if not report.passed or report.has_survivorship_bias_risk
]

print(f"\nExcluded from WFO: {excluded}")

# Proceed with clean universe
clean_universe = {
    ticker: universe[ticker]
    for ticker in universe
    if ticker not in excluded
}
```

---

## ⚙️ Configuration

### DataQualityValidator Parameters

```python
validator = DataQualityValidator(
    max_missing_pct=5.0,           # Max % missing data
    extreme_move_threshold=0.20,    # 20% single-day move
    price_spike_threshold=3.0,      # 3 std devs from mean
    min_volume_threshold=1000,      # Minimum volume
    zero_volume_critical=True       # Zero volume = critical
)
```

### Selective Validation

```python
# Only run specific checks
report = validator.validate(
    data,
    check_survivorship=True,        # Check delisting
    check_corporate_actions=True,   # Check splits/dividends
    check_price_anomalies=False,    # Skip price checks
    check_volume=True               # Check volume
)
```

---

## 📋 Integration with Data Pipeline

### Step 1.3 + Step 1.4 Together

```python
from raits.data.raits_data_pipeline import DataPipeline
from raits.data.raits_data_validator import validate_data

# 1. Fetch data (Step 1.3)
pipeline = DataPipeline(api_key=None)
data = pipeline.get_daily_data("AAPL", start, end)

# 2. Validate data (Step 1.4)
report = validate_data(data)

# 3. Decision
if report.passed:
    # Use data
    df = data.to_dataframe()
    # Proceed with strategy development
else:
    # Handle failure
    print("Data quality issues:")
    for issue in report.get_critical_issues():
        print(f"  - {issue}")
    # Either fix data or exclude ticker
```

### Workflow

```
Fetch Data (1.3) → Validate (1.4) → Pass? → Use for Backtesting
                                  ↓ Fail
                                  → Fix or Exclude
```

---

## 🧪 Testing

### Test Step 1.4 Works

```python
# test_step_1_4.py
from raits.data.raits_mock_data import generate_mock_daily_data
from raits.data.raits_data_validator import validate_data

# Generate test data
data = generate_mock_daily_data("TEST", days=252)

# Validate
report = validate_data(data)

# Assertions
assert report is not None
assert report.quality_score >= 0
assert report.quality_score <= 100
assert len(report.issues) >= 0

print(f"✓ Quality score: {report.quality_score}/100")
print(f"✓ Status: {'PASS' if report.passed else 'FAIL'}")
print("✅ Step 1.4: VALIDATION WORKING!")
```

Run it:
```bash
python test_step_1_4.py
```

---

## ✅ Checklist: Step 1.4 Complete

Before moving on, verify:

- [ ] **raits_data_validator.py** copied to `raits/data/`
- [ ] **example_data_validation.py** works
- [ ] Can validate single ticker
- [ ] Can validate universe
- [ ] Quality scoring works (0-100)
- [ ] Pass/fail decisions work
- [ ] Understand survivorship bias
- [ ] Know how to filter bad data

**Time:** 1-2 hours to understand and integrate

---

## 🎯 When to Use This

### Development Phase (NOW)

**Use for:**
- Learning what validation checks exist
- Understanding data quality issues
- Testing with mock data

**Don't worry about:**
- Survivorship bias (mock data doesn't have it)
- Real corporate actions (mock data is simple)

### WFO Phase (Week 19)

**Critical for:**
- Filtering universe before Walk-Forward Optimization
- Ensuring Point-in-Time data accuracy
- Avoiding survivorship bias
- Detecting bad data that would skew results

### Vault Test (Week 21)

**Required:**
- Final validation of all data
- Confirm no lookahead bias
- Document data quality in results

---

## 💡 Key Insights

### Survivorship Bias is Critical

**Bad approach:**
```python
# Download only currently-traded stocks
universe = ["AAPL", "MSFT", "GOOGL", ...]  # All winners!

# Backtest shows 30% annual return
# But you're only testing on survivors
```

**Good approach:**
```python
# Include delisted stocks
universe = all_stocks_traded_in_period(2020, 2024)

# Validate each ticker
reports = validate_universe(universe)

# Flag survivorship bias risk
risky = [t for t, r in reports.items() if r.has_survivorship_bias_risk]
print(f"Survivorship risk: {risky}")
```

### Quality != Profitability

**Important:**
- High quality data doesn't mean profitable trades
- Low quality data doesn't mean unprofitable
- Quality = Reliability of backtest results

**Use quality for:**
- ✓ Trusting backtest results
- ✓ Avoiding false signals from bad data
- ✓ Reducing debugging time

**Don't use quality for:**
- ✗ Picking which stocks to trade (that's strategy's job)
- ✗ Predicting future returns

---

## 🔜 Next Steps

**After Step 1.4:**

You've now completed **ALL of Step 1** (Environment & Data Pipeline):
```
✅ Step 1.1: Python Environment
⏸️ Step 1.2: Polygon.io API (optional for now)
✅ Step 1.3: Data Ingestion Pipeline
✅ Step 1.4: Data Quality Validation
```

**Recommended next:**

1. **Section 12: Testing Infrastructure** (2-3 days)
   - Build logging system
   - Create test framework
   - Set up per-module testing

2. **Section 3: HMM Regime Detection** (1 week)
   - Build 3-state HMM model
   - Use validated data from Step 1

3. **Section 4: Trading Strategies** (4-6 weeks)
   - ORB, VWAP, Trend, Cash modes
   - All with validated data

---

## 📚 Additional Resources

**Related Blueprint Sections:**
- Section 2.1: Data Requirements (Point-in-Time data)
- Section 7: Walk-Forward Optimization (when you'll need this most)
- Section 8: Vault Test (final validation)

**Academic Papers:**
- Survivorship bias in backtesting
- Corporate action adjustments
- Data quality in quantitative finance

---

**Document Status:** Production-Ready  
**Last Updated:** February 27, 2026  
**Next:** Section 12 (Testing Infrastructure) or Section 3 (HMM)

---

## 🎯 Summary

**What you built:**
- Comprehensive data quality validation
- Survivorship bias detection
- Corporate action verification
- Price & volume anomaly detection
- Quality scoring system (0-100)
- Universe filtering capabilities

**What you can do:**
- Validate data before backtesting
- Filter out low-quality tickers
- Detect survivorship bias
- Ensure Point-in-Time data accuracy
- Make informed pass/fail decisions

**Cost:** $0 (works with mock data)

**Step 1: COMPLETE** ✅

You now have production-grade data infrastructure ready for RAITS development!
